#include<stdio.h>
#include<conio.h>


void reverse_string(char* str) {
    int length, i;
    char *begin_ptr, *end_ptr, ch;

    length = 0;
    begin_ptr = str;

    while (*str != '\0') {
        length++;
        str++;
    }

    str = begin_ptr;

    end_ptr = str + length - 1;

    for (i = 0; i < length / 2; i++) {
        ch = *str;
        *str = *end_ptr;
        *end_ptr = ch;
        str++;
        end_ptr--;
    }
}

int main() {
    char str[100];

    printf("Enter a string: ");
    scanf("%99s", str);

    reverse_string(str);

    printf("Reverse of the string: %s\n", str);

    return 0;
}
